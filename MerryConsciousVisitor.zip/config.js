module.exports = {

    Developers: "648607274071490576", // ايدي تبعك

    Bot: {
        ClientID: "1230967628571345027", // ايدي البوت
        Color: "BLURPLE", // مش مهمه
    },


    comeRole: "1230617178605359125", // الي يقدر يستخدم امر come

}